import React from 'react';

const RegistrationForm = () => {
  return (
    <form>
      <div>
        <label>Username:</label>
        <input type="text" required />
      </div>
      <div>
        <label>Email:</label>
        <input type="email" required />
      </div>
      <div>
        <label>Password:</label>
        <input type="password" required />
      </div>
      <div>
        <label>Confirm Password:</label>
        <input type="password" required />
      </div>
      <div>
        <label>Phone Number:</label>
        <input type="tel" required />
      </div>
      <button type="submit">Register</button>
    </form>
  );
};

export default RegistrationForm;
