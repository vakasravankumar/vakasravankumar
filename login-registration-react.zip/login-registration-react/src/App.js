import React from 'react';
import LoginForm from './loginForm';
import RegistrationForm from './registrationForm';
import './App.css';

const App = () => {
  return (
    <div className="container">
      <div className="form-container">
        <h2>Login</h2>
        <LoginForm />
      </div>
      <div className="form-container">
        <h2>Register</h2>
        <RegistrationForm />
      </div>
    </div>
  );
};

export default App;
